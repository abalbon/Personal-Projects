#ifndef HEADER_H_
#define HEADER_H_

#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include <string>
using namespace std;

// Token Class that contains the token and the lexeme
class Token
{
private:
  string tt;
  string lexeme;
public:
  Token(){}
  // Token Constructor
  Token(string tt, string lexeme)
  {
    this->tt = tt;
    this->lexeme = lexeme;
  }
  // Class function that prints out a single element
  void printToken()
  {
    cout << setw(15) << left << tt << lexeme << endl;
  }
  // Get token type
  string getTokenType()
  {
    return tt;
  }
  // Get Lexeme
  string getLex()
  {
    return lexeme;
  }
};

class RDP
{
private:
  vector<Token> listOfTokens;
  int tokenIndex;
  vector<string> listOfProductionRules;
public:
  // Default Constructor
  RDP(){}
  // Alternate Constructor
  RDP(vector<Token> listOfTokens)
  {
    this->listOfTokens = listOfTokens;
    tokenIndex = 0;
  }
  // Retrieves the current index
  int getIndex()
  {
    return tokenIndex;
  }
  void printProductionRules()
  {
    for(int i = listOfProductionRules.size() - 1; i != -1; i--)
    {
      cout << listOfProductionRules.at(i) << endl;
    }
  }
  void parse()
  {
    while(tokenIndex < listOfTokens.size())
    {
      if(E() == false)
      {
        listOfProductionRules.clear();
        cout << "\n\nFailure\n";
        cout << "There was no production rule for: "
             << listOfTokens.at(tokenIndex).getLex() << endl;
        break;
      }
      else
      {
        listOfTokens.at(tokenIndex).printToken();
        printProductionRules();
        cout << "--------------------------------------" << endl;
        listOfProductionRules.clear();
        tokenIndex++;
      }
    }
  }

  //Production Rules
  bool E()
  {
    bool e = false;
    if(T())
    {
      listOfProductionRules.push_back("E --> TQ");
      e = true;
    }
    if(Q())
    {
      listOfProductionRules.push_back("E --> TQ");
      e = true;
    }

    return e;
  }

  bool Q()
  {
    bool q = false;
    if(listOfTokens.at(tokenIndex).getLex() == "+")
    {
        listOfProductionRules.push_back("Q --> +TQ");
        q = true;
    }
    if(listOfTokens.at(tokenIndex).getLex() == "-")
    {
        listOfProductionRules.push_back("Q --> -TQ");
        q = true;
    }

    return q;

  }

  bool T()
  {
    bool t = false;
    if(F())
    {
      listOfProductionRules.push_back("T --> FR");
      t = true;
    }
    if(R())
    {
      listOfProductionRules.push_back("T --> FR");
      t = true;
    }
    return t;
  }

  bool R()
  {
    bool r = false;

    if(listOfTokens.at(tokenIndex).getLex() == "*")
    {
      listOfProductionRules.push_back("R --> *FR");
      r = true;
    }
    if(listOfTokens.at(tokenIndex).getLex() == "/")
    {
      listOfProductionRules.push_back("R --> /FR");
      r = true;
    }

    return r;
  }

  bool F()
  {
    bool f = false;
    if(listOfTokens.at(tokenIndex).getTokenType() == "Identifier")
    {
      listOfProductionRules.push_back("F --> id");
      f = true;
    }
    if(listOfTokens.at(tokenIndex).getLex() == "(")
    {
      listOfProductionRules.push_back("F --> (E)");
      f = true;

    }

    return f;
  }

};

#endif
